// ------------step-wizard-------------
$(document).ready(function () {
    $('.nav-tabs > li a[title]').tooltip();
    
    //Wizard
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {

        var target = $(e.target);
    
        if (target.parent().hasClass('disabled')) {
            return false;
        }
    });

    $(".next-step").click(function (e) {

        var active = $('.wizard .nav-tabs li.active');
        active.next().removeClass('disabled');
        nextTab(active);

    });
    $(".prev-step").click(function (e) {

        var active = $('.wizard .nav-tabs li.active');
        prevTab(active);

    });
});

function nextTab(elem) {
    $(elem).next().find('a[data-toggle="tab"]').click();
}
function prevTab(elem) {
    $(elem).prev().find('a[data-toggle="tab"]').click();
}


$('.nav-tabs').on('click', 'li', function() {
    $('.nav-tabs li.active').removeClass('active');
    $(this).addClass('active');
});







const jobs = [
    "Leads", "Investment", "Accountant", "Auditor", "CA", "Secretary", "Finance", "Tally Operator",
    "Tax Assistants", "2D/3D Architect", "Quality Control Manager", "AutoCAD Designer", "Restaurant Manager", "Supervisor",
    "Warehouse Executive", "Beautician", "Body Massage Therapist", "Hair Cutting Executive", "Hair Dresser", "Laser Hair Removal Tech",
    "Furniture Designer", "Interior Designer", "Modular Kitchen Designer", "Admin Executive", "Back Office Executive",
    "Business Development Exec", "Business Development Mnr", "Business Operation", "Clerk", "CSR Manager", "Computer Operator",
    "Data Entry Operator", "Ecommerce Operation", "Hotel Manager", "Housekeeping", "Inventory Manager", "Logistic Manager",
    "MIS Executive", "Office Coordinator", "Purchase Manager", "Mehandi Artist", "Nail Art", "SPA Therapist", "Business Analyst",
    "Relationship Manager", "Sales Executive", "Content Analyst", "Content Editor", "Content Writer", "Editor", "Chef",
    "Academic Counselor", "Career Counselor", "Investment Counselor", "Collection", "Delivery Executive", "Driver", "DTP Operator",
    "Civil Engineer", "Electrical Engineer", "Maintenance Engineer", "Event Coordinator", "Fashion Designer", "Area Sales Manager",
    "Promoter", "Graphic Designer", "Photographer", "UI/UX Designer", "Video Editor", "IT Engineer", "Human Resource Executive",
    "Lab Technician", "Advocate", "Doctor", "Nurse", "Digital Marketing", "Web Developer", "Security", "Teacher"
];

const jobContainer = document.getElementById("jobContainer");
let loadedJobs = 30; // Load first 30 jobs

function loadJobs(start, end) {
    const fragment = document.createDocumentFragment();

    for (let i = start; i < end && i < jobs.length; i++) {
        const colDiv = document.createElement("div");
        colDiv.classList.add("col-lg-2", "col-md-4", "col-sm-6", "mb-3");

        colDiv.innerHTML = `
            <div class="job-option">
                <input type="checkbox" id="job${i}">
                <label for="job${i}">${jobs[i]}</label>
            </div>
        `;

        fragment.appendChild(colDiv);
    }
    jobContainer.appendChild(fragment);
}

function loadMoreJobs() {
    loadJobs(loadedJobs, loadedJobs + 12); // Load in batches of 12
    loadedJobs += 12;
    if (loadedJobs >= jobs.length) {
        document.querySelector(".more-button").style.display = "none";
    }
}

// Load initial jobs
loadJobs(0, loadedJobs);
